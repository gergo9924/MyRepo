import React from 'react'

function Example() {
  return (
    <div>Example</div>
  )
}

export default Example