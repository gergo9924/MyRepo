import React from "react"

export const GuestContext = React.createContext()